Magento 2 Training Seller Module
================================

Description
-----------

This module adds the possibility to manage sellers.


Install
-------


Execute the following command on your main project folder to add the module :

> composer require training/module-seller


Magento versions compatibility
------------------------------

* CE : 2.2.x
* EE : 2.2.x


Contact
-------

Laurent MINGUET <lamin@smile.fr>

